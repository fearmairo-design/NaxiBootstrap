using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace NaxiBootstrap;

public partial class MainWindow : Window
{
    private const string AppVersion = "v1.1.0";

    private const string GitHubRepo = "fearmairo-design/NaxiBootstrap";

    private const string DiscordUrl = "https://discord.gg/";

    private static string UpdateLogUrl => $"https://raw.githubusercontent.com/{GitHubRepo}/main/updatelog.json";
    private static string ReleasesApiUrl => $"https://api.github.com/repos/{GitHubRepo}/releases/latest";

    private static readonly string LogFile = Path.Combine(AppContext.BaseDirectory, "updatelog.json");
    private static readonly string UpdateZip = Path.Combine(Path.GetTempPath(), "NaxiBootstrap.update.zip");
    private static readonly string UpdateDir = Path.Combine(Path.GetTempPath(), "NaxiBootstrap.update");
    private static readonly string UpdateScript = Path.Combine(Path.GetTempPath(), "NaxiBootstrap.update.cmd");

    private static readonly HttpClient Http = new();

    private readonly Grid _home;
    private readonly Grid _configs;
    private readonly Grid _settings;
    private readonly StackPanel _updateList = new();

    private List<LogEntry> _log;

    private TextBlock _versionBadge = new();
    private TextBlock _updateText = new();
    private TextBlock _percent = new();
    private ProgressBar _progress = new();
    private Button _updateBtn = new();

    private bool _updating;

    static MainWindow()
    {
        Http.DefaultRequestHeaders.Add("User-Agent", "NaxiBootstrap");
    }

    public MainWindow()
    {
        InitializeComponent();

        _log = LoadLog();
        _home = BuildHome();
        _configs = BuildConfigs();
        _settings = BuildSettings();

        PageHost.Content = _home;
        SetActive(HomeNav);
        RenderLog(_log);
        _ = CheckForUpdatesAsync();
    }

    private void DragWindow(object sender, MouseButtonEventArgs e)
    { if (e.LeftButton == MouseButtonState.Pressed) DragMove(); }

    private void SetActive(Button active)
    {
        foreach (var b in new[] { HomeNav, ConfigNav, SettingsNav })
            b.Style = (Style)FindResource(b == active ? "NavButtonActive" : "NavButton");
    }

    private void Home_Click(object sender, RoutedEventArgs e) { PageHost.Content = _home; SetActive(HomeNav); }
    private void Config_Click(object sender, RoutedEventArgs e) { PageHost.Content = _configs; SetActive(ConfigNav); }
    private void Settings_Click(object sender, RoutedEventArgs e) { PageHost.Content = _settings; SetActive(SettingsNav); }
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private Grid BuildHome()
    {
        var g = new Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(470) });

        var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(84, 0, 40, 0) };
        left.Children.Add(T("Free external utility", 16, (Brush)FindResource("Muted"), false));
        left.Children.Add(new TextBlock
        {
            Text = "Naxi",
            FontSize = 80,
            FontWeight = FontWeights.Bold,
            Foreground = (Brush)FindResource("TitleGradient"),
            Margin = new Thickness(0, 4, 0, 0)
        });

        var badges = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 24, 0, 0) };
        _versionBadge = T(AppVersion, 15, (Brush)FindResource("AccentText"), true);
        badges.Children.Add(new Border { Background = (Brush)FindResource("Accent"), CornerRadius = new CornerRadius(16), Padding = new Thickness(16, 7, 16, 7), Child = _versionBadge });
        badges.Children.Add(new Border { Background = (Brush)FindResource("Surface2"), BorderBrush = (Brush)FindResource("Stroke"), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), Padding = new Thickness(16, 7, 16, 7), Margin = new Thickness(12, 0, 0, 0), Child = T("Windows 10/11", 15, (Brush)FindResource("Text"), true) });
        left.Children.Add(badges);

        var updateBlock = new StackPanel { Margin = new Thickness(0, 36, 0, 0) };
        _updateText = T("Checking for updates...", 21, (Brush)FindResource("Text"), true);
        updateBlock.Children.Add(_updateText);
        _progress = new ProgressBar { Minimum = 0, Maximum = 100, Value = 0, Margin = new Thickness(0, 16, 0, 0) };
        updateBlock.Children.Add(_progress);
        _percent = T("0%", 13, (Brush)FindResource("Muted"), false, 8);
        updateBlock.Children.Add(_percent);
        left.Children.Add(updateBlock);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 34, 0, 0) };
        _updateBtn = Btn("Update", false, 152); _updateBtn.IsEnabled = false; _updateBtn.Click += Update_Click;
        var launch = Btn("Launch", false, 152); launch.Margin = new Thickness(14, 0, 0, 0); launch.Click += Launch_Click;
        var discord = Btn("Join Discord", false, 168); discord.Margin = new Thickness(14, 0, 0, 0); discord.Click += Discord_Click;
        buttons.Children.Add(_updateBtn); buttons.Children.Add(launch); buttons.Children.Add(discord);
        left.Children.Add(buttons);

        Grid.SetColumn(left, 0); g.Children.Add(left);

        var logCard = new Border { Style = (Style)FindResource("Card"), Padding = new Thickness(26), Margin = new Thickness(6, 16, 26, 0) };
        var logGrid = new Grid();
        logGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        logGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        logGrid.Children.Add(T("UPDATE LOG", 13, (Brush)FindResource("Muted"), true));
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Margin = new Thickness(0, 16, 0, 0) };
        scroll.Content = _updateList;
        Grid.SetRow(scroll, 1); logGrid.Children.Add(scroll);
        logCard.Child = logGrid;
        Grid.SetColumn(logCard, 1); g.Children.Add(logCard);

        return g;
    }

    private async Task CheckForUpdatesAsync()
    {
        try
        {
            var remote = await FetchRemoteLogAsync();
            if (remote is { Count: > 0 })
            {
                _log = remote;
                RenderLog(_log);
            }

            var (tag, _) = await GetLatestReleaseAsync();
            if (IsNewer(tag))
            {
                _updateText.Text = $"Update available: {tag}";
                _updateBtn.IsEnabled = true;
            }
            else
            {
                _updateText.Text = "Naxi is up to date";
            }
        }
        catch
        {
            _updateText.Text = "Could not check for updates";
        }
    }

    private async void Update_Click(object sender, RoutedEventArgs e)
    {
        if (_updating) return;
        _updating = true;
        _updateBtn.IsEnabled = false;

        try
        {
            var (tag, asset) = await GetLatestReleaseAsync();
            if (asset == null) throw new InvalidOperationException("Release has no .zip asset");

            _updateText.Text = $"Downloading {tag}...";
            await DownloadAsync(asset, UpdateZip);

            _updateText.Text = "Installing...";
            _progress.Value = 100;
            _percent.Text = "100%";

            if (Directory.Exists(UpdateDir)) Directory.Delete(UpdateDir, true);
            ZipFile.ExtractToDirectory(UpdateZip, UpdateDir);

            var source = UpdateDir;
            if (Directory.GetFiles(UpdateDir).Length == 0 && Directory.GetDirectories(UpdateDir).Length == 1)
                source = Directory.GetDirectories(UpdateDir)[0];

            var appDir = AppContext.BaseDirectory;
            var script =
                "@echo off\r\n" +
                "timeout /t 2 /nobreak >nul\r\n" +
                $"xcopy /e /i /y \"{source}\\*\" \"{appDir}\"\r\n" +
                $"rmdir /s /q \"{UpdateDir}\"\r\n" +
                $"start \"\" \"{Path.Combine(appDir, "NaxiBootstrap.exe")}\"\r\n";
            File.WriteAllText(UpdateScript, script);

            Process.Start(new ProcessStartInfo("cmd.exe", $"/c \"{UpdateScript}\"") { CreateNoWindow = true, UseShellExecute = false });
            Close();
        }
        catch
        {
            _updateText.Text = "Update failed, try again";
            _progress.Value = 0;
            _percent.Text = "0%";
            _updateBtn.IsEnabled = true;
            _updating = false;
        }
    }

    private async Task<(string Tag, string? AssetUrl)> GetLatestReleaseAsync()
    {
        using var doc = JsonDocument.Parse(await Http.GetStringAsync(ReleasesApiUrl));
        var root = doc.RootElement;
        var tag = root.GetProperty("tag_name").GetString() ?? "";
        string? asset = null;
        if (root.TryGetProperty("assets", out var assets))
        {
            foreach (var a in assets.EnumerateArray())
            {
                var name = a.GetProperty("name").GetString() ?? "";
                if (name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    asset = a.GetProperty("browser_download_url").GetString();
                    break;
                }
            }
        }
        return (tag, asset);
    }

    private async Task<List<LogEntry>?> FetchRemoteLogAsync()
    {
        var json = await Http.GetStringAsync(UpdateLogUrl);
        var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        return JsonSerializer.Deserialize<List<LogEntry>>(json, opts);
    }

    private async Task DownloadAsync(string url, string dest)
    {
        using var resp = await Http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
        resp.EnsureSuccessStatusCode();
        var total = resp.Content.Headers.ContentLength ?? -1;
        await using var src = await resp.Content.ReadAsStreamAsync();
        await using var dst = File.Create(dest);
        var buffer = new byte[81920];
        long read = 0;
        int n;
        while ((n = await src.ReadAsync(buffer)) > 0)
        {
            await dst.WriteAsync(buffer, 0, n);
            read += n;
            if (total > 0)
            {
                var p = read * 100.0 / total;
                _progress.Value = p;
                _percent.Text = $"{(int)p}%";
            }
        }
    }

    private static bool IsNewer(string tag)
    {
        try { return new Version(tag.TrimStart('v', 'V')) > new Version(AppVersion.TrimStart('v', 'V')); }
        catch { return false; }
    }

    private void Launch_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo { FileName = "roblox-player:", UseShellExecute = true }); }
        catch { MessageBox.Show("Roblox is not installed yet. Install it from roblox.com first.", "Naxi Bootstrap", MessageBoxButton.OK, MessageBoxImage.Information); }
    }

    private void Discord_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo { FileName = DiscordUrl, UseShellExecute = true }); }
        catch { }
    }

    private List<LogEntry> LoadLog()
    {
        try
        {
            if (File.Exists(LogFile))
            {
                var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var list = JsonSerializer.Deserialize<List<LogEntry>>(File.ReadAllText(LogFile), opts);
                if (list is { Count: > 0 }) return list;
            }
        }
        catch { }
        return DefaultLog();
    }

    private static List<LogEntry> DefaultLog() => new()
    {
        new("v1.1.0", null, true, new List<LogChange>
        {
            new("+", "Updated UI"),
            new("+", "Update log"),
            new("~", "Bug fix")
        })
    };

    private sealed record LogChange(string Type, string Text);
    private sealed record LogEntry(string Version, string? Date, bool New, List<LogChange> Changes);

    private void RenderLog(List<LogEntry> log)
    {
        _updateList.Children.Clear();
        foreach (var entry in log)
        {
            var card = new Border { Style = (Style)FindResource("UpdateCard"), Padding = new Thickness(20), Margin = new Thickness(0, 0, 0, 14) };
            var s = new StackPanel();

            var head = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            head.ColumnDefinitions.Add(new ColumnDefinition());
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var ver = T(entry.Version, 20, (Brush)FindResource("Text"), true);
            Grid.SetColumn(ver, 0); head.Children.Add(ver);
            if (entry.New)
            {
                var badge = new Border { Background = (Brush)FindResource("Accent"), CornerRadius = new CornerRadius(8), Padding = new Thickness(11, 4, 11, 4), VerticalAlignment = VerticalAlignment.Center, Child = T("NEW", 11.5, (Brush)FindResource("AccentText"), true) };
                Grid.SetColumn(badge, 1); head.Children.Add(badge);
            }
            else if (entry.Date != null)
            {
                var d = T(entry.Date, 14, (Brush)FindResource("Muted"), false);
                d.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(d, 1); head.Children.Add(d);
            }
            s.Children.Add(head);

            foreach (var c in entry.Changes)
            {
                var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 0) };
                row.Children.Add(new Ellipse { Width = 5, Height = 5, Fill = (Brush)FindResource("Accent"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 0, 10, 0) });
                row.Children.Add(T($"[{c.Type}] {c.Text}", 14.5, (Brush)FindResource("Muted"), false));
                s.Children.Add(row);
            }

            card.Child = s;
            _updateList.Children.Add(card);
        }
    }

    private Grid BuildConfigs()
    {
        var g = new Grid();
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        g.Margin = new Thickness(84, 20, 40, 0);
        var title = new StackPanel();
        title.Children.Add(T("Config library", 30, (Brush)FindResource("Text"), true));
        title.Children.Add(T("Save and switch your Roblox launch profiles.", 13, (Brush)FindResource("Muted"), false, 4));
        Grid.SetRow(title, 0); g.Children.Add(title);
        var cards = new UniformGrid { Columns = 3, Margin = new Thickness(0, 26, 0, 0) };
        cards.Children.Add(ConfigCard("Default", "Balanced Roblox settings.", true));
        cards.Children.Add(ConfigCard("Performance", "Lower overhead and smoother play.", false));
        cards.Children.Add(ConfigCard("Graphics", "Higher visual quality.", false));
        Grid.SetRow(cards, 1); g.Children.Add(cards);
        return g;
    }

    private Border ConfigCard(string name, string desc, bool active)
    {
        var b = new Border { Style = (Style)FindResource("Card"), Margin = new Thickness(0, 0, 14, 14), Padding = new Thickness(22) };
        var s = new StackPanel();
        s.Children.Add(T(name, 19, (Brush)FindResource("Text"), true));
        s.Children.Add(T(desc, 13, (Brush)FindResource("Muted"), false, 7));
        var btn = Btn(active ? "Active" : "Use", active, 96);
        btn.Margin = new Thickness(0, 20, 0, 0);
        s.Children.Add(btn);
        b.Child = s;
        return b;
    }

    private Grid BuildSettings()
    {
        var g = new Grid();
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        g.Margin = new Thickness(84, 20, 40, 0);
        var title = new StackPanel();
        title.Children.Add(T("Settings", 30, (Brush)FindResource("Text"), true));
        title.Children.Add(T("Control how Naxi behaves on your PC.", 13, (Brush)FindResource("Muted"), false, 4));
        Grid.SetRow(title, 0); g.Children.Add(title);
        var card = new Border { Style = (Style)FindResource("Card"), Padding = new Thickness(24), Margin = new Thickness(0, 26, 0, 0), Width = 640, HorizontalAlignment = HorizontalAlignment.Left };
        var s = new StackPanel();
        s.Children.Add(T("General", 17, (Brush)FindResource("Text"), true));
        s.Children.Add(SettingRow("Start minimized", "Open Naxi in the background."));
        s.Children.Add(SettingRow("Check for updates", "Check when Naxi starts."));
        s.Children.Add(SettingRow("Use official Roblox client", "Never replace the Roblox executable."));
        card.Child = s;
        Grid.SetRow(card, 1); g.Children.Add(card);
        return g;
    }

    private UIElement SettingRow(string title, string desc)
    {
        var grid = new Grid { Margin = new Thickness(0, 18, 0, 0) };
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var s = new StackPanel();
        s.Children.Add(T(title, 14, (Brush)FindResource("Text"), true));
        s.Children.Add(T(desc, 12, (Brush)FindResource("Muted"), false, 3));
        Grid.SetColumn(s, 0); grid.Children.Add(s);
        var check = new CheckBox { IsChecked = true, VerticalAlignment = VerticalAlignment.Center, Foreground = (Brush)FindResource("Accent") };
        Grid.SetColumn(check, 1); grid.Children.Add(check);
        return grid;
    }

    private TextBlock T(string text, double size, Brush color, bool bold, double top = 0)
        => new() { Text = text, FontSize = size, Foreground = color, FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal, Margin = new Thickness(0, top, 0, 0), TextWrapping = TextWrapping.Wrap };

    private Button Btn(string text, bool accent, int width)
        => new() { Content = text, Style = (Style)FindResource(accent ? "AccentPillButton" : "PillButton"), Width = width, Height = 50, VerticalAlignment = VerticalAlignment.Top };
}
